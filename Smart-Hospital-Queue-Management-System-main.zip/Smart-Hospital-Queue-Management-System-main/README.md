<div align="center">

# 🏥 Smart Hospital Queue & Operations Management System

An advanced, priority-aware desktop application built with **Java Swing** and **MySQL** for efficient hospital patient queue management and rapid data lookup.

[![Java](https://img.shields.io/badge/Language-Java%2021-orange.svg)](https://www.oracle.com/java/)
[![GUI Framework](https://img.shields.io/badge/UI-Java%20Swing-blue.svg)]()
[![Database](https://img.shields.io/badge/Database-MySQL-00758F.svg)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/License-Academic-brightgreen.svg)]()

---

</div>

## 📌 Project Overview

In fast-paced medical environments, managing patient flow while prioritizing critical emergencies is vital. The **Smart Hospital Queue Management System** automates patient registration, queueing, and consultations. 

By leveraging **Custom Data Structures**—including a Max-Heap for priority triage and a Binary Search Tree for rapid lookups—the system guarantees zero waiting time for life-threatening emergencies while maintaining standard FIFO queues for routine visits.

---

## 🔑 Administrator Credentials & Access

Use these default credentials to log in and review the application features:

| Parameter | Value |
| :--- | :--- |
| **Access Level** | System Administrator |
| **Username** | `admin` |
| **Password** | `admin` |

---

## ✨ Key Features & Functionalities

* **🚨 Triaged Emergency Line (Max-Heap):** Automatically bubbles critical emergency cases to the top of the queue regardless of arrival order.
* **📋 Standard Patient Line (FIFO Queue):** Sequentially handles regular outpatient consultations in arrival order.
* **🔍 Instant Patient Lookup (Binary Search Tree):** Provides $O(\log n)$ efficiency when searching for existing patient records by Patient ID.
* **⏪ Treatment History & Action Undo (Doubly Linked List & Stack):** Logs completed patient treatments and allows reverting accidental queue dispatches.
* **📊 Analytics & Operations Dashboard:** Real-time counters displaying waiting counts, total patients served, and doctor-wise queues.

---

## 🛠️ Custom Data Structures Architecture

The application strictly implements non-generic/custom data structures tailored for the workflow:

```text
                          ┌────────────────────────┐
                          │  Patient Registration  │
                          └───────────┬────────────┘
                                      │
                      ┌───────────────┴───────────────┐
                      │ Is Emergency Case?            │
                      └───────┬───────────────┬───────┘
                              │               │
                           [ YES ]         [ NO ]
                              │               │
                              ▼               ▼
                 ┌──────────────────┐   ┌──────────────────┐
                 │    MaxHeap       │   │     MyQueue      │
                 │ (Priority Triage)│   │ (Standard Line)  │
                 └────────┬─────────┘   └────────┬─────────┘
                          │               │
                          └───────┬───────┘
                                  │
                                  ▼
                   ┌─────────────────────────────┐
                   │ Doctor Consultation Dispatch │
                   └──────────────┬──────────────┘
                                  │
                 ┌────────────────┴────────────────┐
                 │                                 │
                 ▼                                 ▼
      ┌────────────────────┐            ┌────────────────────┐
      │ BinarySearchTree   │            │  DoublyLinkedList  │
      │  (Fast Search ID)  │            │ (History Logging)  │
      └────────────────────┘            └────────────────────┘

---

## 🛠️ Package Structure

src/com/pdsa/hospital/
├── controller/        # Business logic & services
│   ├── PatientService.java
│   ├── QueueService.java
│   └── ReportService.java
├── database/          # Connection & database queries
│   └── Database.java
├── datastructure/     # Custom data structure implementations
│   ├── BinarySearchTree.java
│   ├── DoublyLinkedList.java
│   ├── DoublyNode.java
│   ├── MaxHeap.java
│   ├── MyQueue.java
│   ├── MyStack.java
│   ├── Node.java
│   └── TreeNode.java
├── model/             # Models & Data entities
│   ├── Doctor.java
│   └── Patient.java
└── view/              # Java Swing presentation layers
    ├── DashboardUI.java
    ├── HistoryUI.java
    ├── LoginUI.java
    ├── QueueUI.java
    └── RegisterPatientUI.java
