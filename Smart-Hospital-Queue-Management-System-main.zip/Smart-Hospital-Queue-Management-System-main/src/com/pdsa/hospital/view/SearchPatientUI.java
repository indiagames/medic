package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.PatientService;
import com.pdsa.hospital.model.Patient;

public class SearchPatientUI extends JFrame {
    private JTextField txtSearchId;
    private JTextArea txtResult;
    private JButton btnSearch;

    public SearchPatientUI(PatientService patientService) {
        setTitle("Search Registry - Binary Search Tree");
        setSize(480, 380);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(245, 247, 250));

        JPanel searchBarPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        searchBarPanel.setBackground(new Color(245, 247, 250));

        JLabel lblId = new JLabel("Enter Patient ID:");
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 13));

        txtSearchId = new JTextField(10);
        txtSearchId.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnSearch.setBackground(new Color(142, 36, 170));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);

        searchBarPanel.add(lblId);
        searchBarPanel.add(txtSearchId);
        searchBarPanel.add(btnSearch);
        mainPanel.add(searchBarPanel, BorderLayout.NORTH);

        txtResult = new JTextArea();
        txtResult.setEditable(false);
        txtResult.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtResult.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        mainPanel.add(new JScrollPane(txtResult), BorderLayout.CENTER);
        add(mainPanel);

        // Search Action with Validation
        btnSearch.addActionListener(e -> {
            String input = txtSearchId.getText().trim();
            if (input.isEmpty() || !input.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid numeric Patient ID.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int id = Integer.parseInt(input);
            Patient found = patientService.findPatientById(id);

            if (found != null) {
                txtResult.setText("=== PATIENT RECORD FOUND ===\n\n" + found.toString());
            } else {
                txtResult.setText("❌ No patient found matching ID: " + id);
            }
        });
    }
}