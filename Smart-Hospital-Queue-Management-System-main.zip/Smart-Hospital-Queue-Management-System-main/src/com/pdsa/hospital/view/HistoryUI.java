package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.datastructure.DoublyNode;
import com.pdsa.hospital.model.Patient;

public class HistoryUI extends JFrame {
    private JTextArea txtHistory;
    private QueueService queueService;

    public HistoryUI(QueueService qService) {
        this.queueService = qService;

        setTitle("Smart Hospital - Consultation History");
        setSize(520, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(245, 247, 250));

        // Header Title
        JLabel lblHeader = new JLabel("Completed Consultations (Doubly Linked List)", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblHeader.setForeground(new Color(230, 81, 0));
        mainPanel.add(lblHeader, BorderLayout.NORTH);

        // History Log Text Area
        txtHistory = new JTextArea();
        txtHistory.setEditable(false);
        txtHistory.setFont(new Font("Consolas", Font.PLAIN, 13));
        txtHistory.setBackground(Color.WHITE);
        txtHistory.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        mainPanel.add(new JScrollPane(txtHistory), BorderLayout.CENTER);
        add(mainPanel);

        // Populate history from Doubly Linked List
        loadHistoryData();
    }

    private void loadHistoryData() {
        StringBuilder sb = new StringBuilder();
        sb.append("===================================================\n");
        sb.append("        COMPLETED PATIENT CONSULTATIONS LOG       \n");
        sb.append("===================================================\n\n");

        DoublyNode<Patient> current = queueService.getHistoryList().getHead();
        if (current == null) {
            sb.append(" ℹ️ No historical consultation logs recorded yet.\n");
        } else {
            int count = 1;
            while (current != null) {
                sb.append(String.format(" %2d. [Served] ID: %-5d | %-18s | Dr. %s\n",
                        count++,
                        current.data.getPatientId(),
                        current.data.getPatientName(),
                        current.data.getDoctorName()));
                current = current.next;
            }
        }

        txtHistory.setText(sb.toString());
    }
}