package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.PatientService;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.controller.ReportService;

public class LoginUI extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public LoginUI(PatientService pService, QueueService qService, ReportService rService) {
        setTitle("Smart Hospital - Login");
        setSize(380, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        mainPanel.setBackground(new Color(245, 247, 250));

        JLabel lblTitle = new JLabel("System Login", JLabel.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(new Color(40, 53, 147));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 15));
        formPanel.setBackground(new Color(245, 247, 250));

        JLabel lblUser = new JLabel("Username:");
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 13));
        txtUsername = new JTextField();

        JLabel lblPass = new JLabel("Password:");
        lblPass.setFont(new Font("Segoe UI", Font.BOLD, 13));
        txtPassword = new JPasswordField();

        formPanel.add(lblUser);
        formPanel.add(txtUsername);
        formPanel.add(lblPass);
        formPanel.add(txtPassword);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBackground(new Color(40, 53, 147));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);

        mainPanel.add(btnLogin, BorderLayout.SOUTH);
        add(mainPanel);

        btnLogin.addActionListener(e -> {
            String user = txtUsername.getText().trim();
            String pass = new String(txtPassword.getPassword()).trim();

            if (user.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter both Username and Password.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (user.equals("admin") && pass.equals("admin")) {
                dispose();
                new DashboardUI(pService, qService, rService).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials! Try admin / admin", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}