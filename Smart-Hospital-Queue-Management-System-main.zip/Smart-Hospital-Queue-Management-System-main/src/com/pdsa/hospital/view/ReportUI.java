package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.controller.ReportService;

public class ReportUI extends JFrame {

    public ReportUI(QueueService qService, ReportService rService) {
        setTitle("Smart Hospital - Operational Analytics");
        setSize(460, 360);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(245, 247, 250));

        // Header Title
        JLabel lblHeader = new JLabel("Daily Summary Report", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(57, 73, 171));
        mainPanel.add(lblHeader, BorderLayout.NORTH);

        // Report Text Display
        JTextArea txtReport = new JTextArea();
        txtReport.setEditable(false);
        txtReport.setFont(new Font("Segoe UI", Font.BOLD, 14));
        txtReport.setBackground(Color.WHITE);
        txtReport.setForeground(new Color(33, 33, 33));
        txtReport.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)));

        mainPanel.add(new JScrollPane(txtReport), BorderLayout.CENTER);

        // Fetch daily analytics from logic layer
        String dailyReport = rService.generateDailyReport(qService);
        txtReport.setText(dailyReport);

        add(mainPanel);
    }
}