package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.PatientService;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.controller.ReportService;

public class DashboardUI extends JFrame {

    public DashboardUI(PatientService pService, QueueService qService, ReportService rService) {
        setTitle("Smart Hospital Management - Main Dashboard");
        setSize(650, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setBorder(new EmptyBorder(25, 25, 25, 25));
        mainPanel.setBackground(new Color(240, 244, 248));

        // Top Header Title
        JPanel headerPanel = new JPanel(new GridLayout(2, 1));
        headerPanel.setBackground(new Color(240, 244, 248));
        JLabel lblTitle = new JLabel("Smart Hospital Queue System", JLabel.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(26, 35, 126));

        JLabel lblSub = new JLabel("Welcome, Administrator", JLabel.CENTER);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(new Color(100, 116, 139));

        headerPanel.add(lblTitle);
        headerPanel.add(lblSub);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Center Grid Buttons
        JPanel gridPanel = new JPanel(new GridLayout(3, 2, 18, 18));
        gridPanel.setBackground(new Color(240, 244, 248));

        JButton btnRegister = createMenuButton("Register Patient", new Color(30, 136, 229));
        JButton btnQueue = createMenuButton("Live Queue Monitor", new Color(0, 150, 136));
        JButton btnSearch = createMenuButton("Search Patient (BST)", new Color(142, 36, 170));
        JButton btnHistory = createMenuButton("Patient History (DLL)", new Color(230, 81, 0));
        JButton btnReport = createMenuButton("Daily Reports", new Color(57, 73, 171));
        JButton btnLogout = createMenuButton("Logout", new Color(198, 40, 40));

        gridPanel.add(btnRegister);
        gridPanel.add(btnQueue);
        gridPanel.add(btnSearch);
        gridPanel.add(btnHistory);
        gridPanel.add(btnReport);
        gridPanel.add(btnLogout);
        mainPanel.add(gridPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Actions
        btnRegister.addActionListener(e -> new RegisterPatientUI(pService, qService).setVisible(true));
        btnQueue.addActionListener(e -> new QueueUI(qService).setVisible(true));
        btnSearch.addActionListener(e -> new SearchPatientUI(pService).setVisible(true));
        btnHistory.addActionListener(e -> new HistoryUI(qService).setVisible(true));
        btnReport.addActionListener(e -> new ReportUI(qService, rService).setVisible(true));

        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginUI(pService, qService, rService).setVisible(true);
            }
        });
    }

    private JButton createMenuButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}