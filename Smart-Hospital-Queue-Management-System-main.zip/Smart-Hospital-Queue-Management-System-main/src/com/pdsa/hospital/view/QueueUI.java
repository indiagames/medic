package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.datastructure.Node;
import com.pdsa.hospital.model.Patient;

public class QueueUI extends JFrame {
    private JTextArea txtQueueDisplay;
    private JButton btnServe, btnCancel, btnUndo;
    private QueueService queueService;

    public QueueUI(QueueService qService) {
        this.queueService = qService;

        setTitle("Smart Hospital - Live Queue Monitor");
        setSize(580, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Main Panel Container
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(245, 247, 250));

        // Header Panel
        JLabel lblHeader = new JLabel("Live Queue Operations", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblHeader.setForeground(new Color(0, 150, 136));
        mainPanel.add(lblHeader, BorderLayout.NORTH);

        // Queue Display Area
        txtQueueDisplay = new JTextArea();
        txtQueueDisplay.setEditable(false);
        txtQueueDisplay.setFont(new Font("Consolas", Font.PLAIN, 13));
        txtQueueDisplay.setBackground(Color.WHITE);
        txtQueueDisplay.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        JScrollPane scrollPane = new JScrollPane(txtQueueDisplay);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Action Buttons Panel
        JPanel panelButtons = new JPanel(new GridLayout(1, 3, 12, 0));
        panelButtons.setBackground(new Color(245, 247, 250));

        btnServe = createStyledButton("Serve Next", new Color(0, 150, 136));
        btnCancel = createStyledButton("Cancel Current", new Color(211, 47, 47));
        btnUndo = createStyledButton("Undo Cancel", new Color(245, 124, 0));

        panelButtons.add(btnServe);
        panelButtons.add(btnCancel);
        panelButtons.add(btnUndo);
        mainPanel.add(panelButtons, BorderLayout.SOUTH);

        add(mainPanel);

        // Initial Data Populate
        refreshQueueView();

        // Serve next patient action
        btnServe.addActionListener(e -> {
            Patient served = queueService.serveNextPatient();
            if (served != null) {
                JOptionPane.showMessageDialog(this,
                        "Now Serving:\nPatient: " + served.getPatientName() +
                                "\nQueue #: " + served.getQueueNumber() +
                                "\nDoctor: " + served.getDoctorName(),
                        "Patient Called", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No patients remaining in queue.", "Queue Empty", JOptionPane.WARNING_MESSAGE);
            }
            refreshQueueView();
        });

        // Cancel appointment action
        btnCancel.addActionListener(e -> {
            Patient toCancel = queueService.getRegularQueue().dequeue();
            if (toCancel != null) {
                queueService.cancelAppointment(toCancel);
                JOptionPane.showMessageDialog(this, "Cancelled Appointment:\n" + toCancel.getPatientName(), "Cancelled", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No standard appointments to cancel.", "Notice", JOptionPane.INFORMATION_MESSAGE);
            }
            refreshQueueView();
        });

        // Undo cancellation action
        btnUndo.addActionListener(e -> {
            Patient restored = queueService.undoCancellation();
            if (restored != null) {
                JOptionPane.showMessageDialog(this, "Restored back to queue:\n" + restored.getPatientName(), "Undo Successful", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No cancelled actions found to undo!", "Stack Empty", JOptionPane.WARNING_MESSAGE);
            }
            refreshQueueView();
        });
    }

    private void refreshQueueView() {
        StringBuilder sb = new StringBuilder();
        sb.append("=====================================================\n");
        sb.append(" CRITICAL EMERGENCY PATIENTS (MAX-HEAP)        \n");
        sb.append("=====================================================\n");

        // Uses your actual MaxHeap method: getHeapElements()
        Patient[] emergencyArray = queueService.getEmergencyHeap().getHeapElements();

        if (emergencyArray.length == 0) {
            sb.append(" [ No active emergency arrivals ]\n");
        } else {
            for (Patient p : emergencyArray) {
                if (p != null) {
                    sb.append(String.format(" ➔ [EMERGENCY] Q-#%-3d | ID: %-5d | Name: %s\n",
                            p.getQueueNumber(), p.getPatientId(), p.getPatientName()));
                }
            }
        }

        sb.append("\n=====================================================\n");
        sb.append(" REGULAR PATIENTS LINE (FIFO QUEUE)           \n");
        sb.append("=====================================================\n");

        Node<Patient> current = queueService.getRegularQueue().getFront();
        if (current == null) {
            sb.append(" [ Standard queue is currently empty ]\n");
        } else {
            while (current != null) {
                sb.append(String.format(" ➔ Q-#%-3d | ID: %-5d | Name: %-20s | Dr. %s\n",
                        current.data.getQueueNumber(),
                        current.data.getPatientId(),
                        current.data.getPatientName(),
                        current.data.getDoctorName()));
                current = current.next;
            }
        }

        txtQueueDisplay.setText(sb.toString());
    }

    private JButton createStyledButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}