package com.pdsa.hospital.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.pdsa.hospital.controller.PatientService;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.database.Database;
import com.pdsa.hospital.model.Doctor;
import com.pdsa.hospital.model.Patient;

public class RegisterPatientUI extends JFrame {
    private JTextField txtId, txtName, txtAge, txtContact;
    private JRadioButton rbMale, rbFemale;
    private ButtonGroup genderGroup;
    private JComboBox<Doctor> comboDoctors;
    private JCheckBox chkEmergency;
    private JButton btnSave, btnClear;

    public RegisterPatientUI(PatientService patientService, QueueService queueService) {
        setTitle("Smart Hospital - Register New Patient");
        setSize(500, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Main Panel with padding
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 25, 20, 25));
        mainPanel.setBackground(new Color(245, 247, 250));

        // Header
        JLabel lblHeader = new JLabel("Patient Registration", JLabel.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblHeader.setForeground(new Color(40, 53, 147));
        mainPanel.add(lblHeader, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 12, 12));
        formPanel.setBackground(new Color(245, 247, 250));

        Font labelFont = new Font("Segoe UI", Font.BOLD, 13);

        formPanel.add(createStyledLabel("Patient ID:", labelFont));
        txtId = createStyledTextField();
        formPanel.add(txtId);

        formPanel.add(createStyledLabel("Full Name:", labelFont));
        txtName = createStyledTextField();
        formPanel.add(txtName);

        formPanel.add(createStyledLabel("Age:", labelFont));
        txtAge = createStyledTextField();
        formPanel.add(txtAge);

        formPanel.add(createStyledLabel("Gender:", labelFont));
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        genderPanel.setBackground(new Color(245, 247, 250));
        rbMale = new JRadioButton("Male", true);
        rbFemale = new JRadioButton("Female");
        rbMale.setBackground(new Color(245, 247, 250));
        rbFemale.setBackground(new Color(245, 247, 250));
        genderGroup = new ButtonGroup();
        genderGroup.add(rbMale);
        genderGroup.add(rbFemale);
        genderPanel.add(rbMale);
        genderPanel.add(rbFemale);
        formPanel.add(genderPanel);

        formPanel.add(createStyledLabel("Contact Number (10 digits):", labelFont));
        txtContact = createStyledTextField();
        formPanel.add(txtContact);

        formPanel.add(createStyledLabel("Assign Doctor:", labelFont));
        comboDoctors = new JComboBox<>();
        comboDoctors.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        for (Doctor doc : Database.getDoctors()) {
            comboDoctors.addItem(doc);
        }
        formPanel.add(comboDoctors);

        formPanel.add(createStyledLabel("Priority Level:", labelFont));
        chkEmergency = new JCheckBox("Emergency Case");
        chkEmergency.setFont(new Font("Segoe UI", Font.BOLD, 13));
        chkEmergency.setForeground(Color.RED);
        chkEmergency.setBackground(new Color(245, 247, 250));
        formPanel.add(chkEmergency);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Bottom Action Buttons Panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setBackground(new Color(245, 247, 250));

        btnClear = new JButton("Clear");
        btnClear.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        btnSave = new JButton("Register & Add to Queue");
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnSave.setBackground(new Color(40, 53, 147));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);

        btnPanel.add(btnClear);
        btnPanel.add(btnSave);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Clear button logic
        btnClear.addActionListener(e -> clearForm());

        // Save button with strict validations
        btnSave.addActionListener(e -> {
            if (validateInputs()) {
                int id = Integer.parseInt(txtId.getText().trim());
                String name = txtName.getText().trim();
                int age = Integer.parseInt(txtAge.getText().trim());
                String gender = rbMale.isSelected() ? "Male" : "Female";
                String contact = txtContact.getText().trim();
                Doctor selectedDoc = (Doctor) comboDoctors.getSelectedItem();
                boolean isEmergency = chkEmergency.isSelected();

                // Check if Patient ID already exists in BST
                if (patientService.findPatientById(id) != null) {
                    JOptionPane.showMessageDialog(this, "A patient with ID " + id + " already exists!", "Duplicate ID", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Patient newPatient = new Patient(id, name, age, gender, contact, selectedDoc.getDoctorName(), isEmergency, 0);

                patientService.registerPatientRecord(newPatient);
                queueService.addPatientToQueue(newPatient);

                JOptionPane.showMessageDialog(this, "Patient Registered Successfully!\nAssigned Queue No: #" + newPatient.getQueueNumber(), "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                dispose();
            }
        });
    }

    private boolean validateInputs() {
        // 1. Patient ID Validation
        String idText = txtId.getText().trim();
        if (idText.isEmpty() || !idText.matches("\\d+")) {
            showError("Patient ID must be a positive number.");
            return false;
        }

        // 2. Name Validation
        String nameText = txtName.getText().trim();
        if (nameText.isEmpty() || !nameText.matches("[a-zA-Z.\\s]+")) {
            showError("Patient Name cannot be empty and should contain letters only.");
            return false;
        }

        // 3. Age Validation
        String ageText = txtAge.getText().trim();
        if (ageText.isEmpty() || !ageText.matches("\\d+")) {
            showError("Age must be a valid number.");
            return false;
        }
        int age = Integer.parseInt(ageText);
        if (age <= 0 || age > 120) {
            showError("Please enter a valid age between 1 and 120.");
            return false;
        }

        // 4. Contact Number Validation (Must be exactly 10 digits)
        String contactText = txtContact.getText().trim();
        if (!contactText.matches("\\d{10}")) {
            showError("Contact number must be exactly 10 digits (e.g., 0771234567).");
            return false;
        }

        // 5. Doctor Selection Validation
        if (comboDoctors.getSelectedItem() == null) {
            showError("Please select a doctor.");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtAge.setText("");
        txtContact.setText("");
        rbMale.setSelected(true);
        chkEmergency.setSelected(false);
    }

    private JLabel createStyledLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(new Color(33, 33, 33));
        return label;
    }

    private JTextField createStyledTextField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        return tf;
    }
}