package com.pdsa.hospital.datastructure;

import com.pdsa.hospital.model.Patient;

public class MaxHeap {
    private Patient[] heap;
    private int size;
    private int capacity;

    public MaxHeap(int capacity) {
        this.capacity = capacity;
        this.heap = new Patient[capacity];
        this.size = 0;
    }

    public void insert(Patient patient) {
        if (size >= capacity) {
            System.out.println("Emergency Queue Full!");
            return;
        }
        heap[size] = patient;
        swim(size);
        size++;
    }

    public Patient extractMax() {
        if (size == 0) return null;
        Patient max = heap[0];
        heap[0] = heap[size - 1];
        size--;
        sink(0);
        return max;
    }

    // New: See who is the top emergency patient without removing them
    public Patient peekMax() {
        if (size == 0) return null;
        return heap[0];
    }

    // New: Clear emergency list
    public void clear() {
        this.size = 0;
    }

    public boolean isEmpty() { return size == 0; }
    public int size() { return size; }

    public Patient[] getHeapElements() {
        Patient[] activeElements = new Patient[size];
        System.arraycopy(heap, 0, activeElements, 0, size);
        return activeElements;
    }

    private void swim(int k) {
        while (k > 0 && isHigherPriority(k, (k - 1) / 2)) {
            swap(k, (k - 1) / 2);
            k = (k - 1) / 2;
        }
    }

    private void sink(int k) {
        while (2 * k + 1 < size) {
            int j = 2 * k + 1;
            if (j + 1 < size && isHigherPriority(j + 1, j)) j++;
            if (!isHigherPriority(j, k)) break;
            swap(k, j);
            k = j;
        }
    }

    private boolean isHigherPriority(int idx1, int idx2) {
        if (heap[idx1].isEmergency() && !heap[idx2].isEmergency()) return true;
        if (!heap[idx1].isEmergency() && heap[idx2].isEmergency()) return false;
        return heap[idx1].getQueueNumber() < heap[idx2].getQueueNumber();
    }

    private void swap(int i, int j) {
        Patient temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }
}