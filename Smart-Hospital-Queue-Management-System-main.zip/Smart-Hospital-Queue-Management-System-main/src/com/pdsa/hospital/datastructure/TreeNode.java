package com.pdsa.hospital.datastructure;

import com.pdsa.hospital.model.Patient;

public class TreeNode {
    public Patient patient;
    public TreeNode left;
    public TreeNode right;

    public TreeNode(Patient patient) {
        this.patient = patient;
        this.left = null;
        this.right = null;
    }
}