package com.pdsa.hospital.datastructure;

import com.pdsa.hospital.model.Patient;

public class DoublyLinkedList<T> {
    private DoublyNode<T> head;
    private DoublyNode<T> tail;
    private int size = 0;

    // 1. Add to the end (Insert)
    public void addLast(T data) {
        DoublyNode<T> newNode = new DoublyNode<>(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    // 2. Delete a specific node (Deletion)
    public boolean delete(T data) {
        DoublyNode<T> current = head;
        while (current != null) {
            if (current.data.equals(data)) {
                if (current == head) {
                    head = head.next;
                    if (head != null) head.prev = null;
                    else tail = null;
                } else if (current == tail) {
                    tail = tail.prev;
                    tail.next = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                size--;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // 3. Traverse Forward (Displaying history from oldest to newest)
    public void printForward() {
        DoublyNode<T> current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }

    // 4. Traverse Backward (Displaying history from newest to oldest - Reverse direction!)
    public void printBackward() {
        DoublyNode<T> current = tail;
        while (current != null) {
            System.out.println(current.data);
            current = current.prev;
        }
    }

    public DoublyNode<T> getHead() { return head; }
    public DoublyNode<T> getTail() { return tail; }
    public boolean isEmpty() { return head == null; }
    public int size() { return size; }
}