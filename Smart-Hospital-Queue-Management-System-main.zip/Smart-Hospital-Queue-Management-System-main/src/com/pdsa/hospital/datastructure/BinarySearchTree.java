package com.pdsa.hospital.datastructure;

import com.pdsa.hospital.model.Patient;

public class BinarySearchTree {
    private TreeNode root;

    public void insert(Patient patient) {
        root = insertRec(root, patient);
    }

    private TreeNode insertRec(TreeNode root, Patient patient) {
        if (root == null) return new TreeNode(patient);
        if (patient.getPatientId() < root.patient.getPatientId()) {
            root.left = insertRec(root.left, patient);
        } else if (patient.getPatientId() > root.patient.getPatientId()) {
            root.right = insertRec(root.right, patient);
        }
        return root;
    }

    public Patient search(int patientId) {
        return searchRec(root, patientId);
    }

    private Patient searchRec(TreeNode root, int patientId) {
        if (root == null || root.patient.getPatientId() == patientId) {
            return root == null ? null : root.patient;
        }
        if (patientId < root.patient.getPatientId()) return searchRec(root.left, patientId);
        return searchRec(root.right, patientId);
    }

    // New: Print all registered patients in sorted order of their IDs
    public void printInOrder() {
        printInOrderRec(root);
    }

    private void printInOrderRec(TreeNode root) {
        if (root != null) {
            printInOrderRec(root.left);
            System.out.println("ID: " + root.patient.getPatientId() + " | Name: " + root.patient.getPatientName());
            printInOrderRec(root.right);
        }
    }
}