package com.pdsa.hospital.model;

public class Doctor {

    private int doctorId;
    private String doctorName;
    private String specialization;
    private String roomNumber;

    public Doctor() {

    }

    public Doctor(int doctorId, String doctorName,
                  String specialization,
                  String roomNumber) {

        this.doctorId = doctorId;
        this.doctorName = doctorName;
        this.specialization = specialization;
        this.roomNumber = roomNumber;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    @Override
    public String toString() {
        return doctorName + " (" + specialization + ")";
    }
}