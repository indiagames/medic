package com.pdsa.hospital.model;

public class Patient {

    private int patientId;
    private String patientName;
    private int age;
    private String gender;
    private String contactNumber;
    private String doctorName;
    private boolean emergency;
    private int queueNumber;

    public Patient() {

    }

    public Patient(int patientId, String patientName, int age,
                   String gender, String contactNumber,
                   String doctorName, boolean emergency,
                   int queueNumber) {

        this.patientId = patientId;
        this.patientName = patientName;
        this.age = age;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.doctorName = doctorName;
        this.emergency = emergency;
        this.queueNumber = queueNumber;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public boolean isEmergency() {
        return emergency;
    }

    public void setEmergency(boolean emergency) {
        this.emergency = emergency;
    }

    public int getQueueNumber() {
        return queueNumber;
    }

    public void setQueueNumber(int queueNumber) {
        this.queueNumber = queueNumber;
    }

    @Override
    public String toString() {
        return "Patient ID : " + patientId +
                "\nName : " + patientName +
                "\nAge : " + age +
                "\nGender : " + gender +
                "\nContact : " + contactNumber +
                "\nDoctor : " + doctorName +
                "\nEmergency : " + emergency +
                "\nQueue Number : " + queueNumber;
    }
}
