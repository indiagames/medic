package com.pdsa.hospital.controller;

import com.pdsa.hospital.database.Database;
import com.pdsa.hospital.datastructure.MyQueue;
import com.pdsa.hospital.datastructure.MaxHeap;
import com.pdsa.hospital.datastructure.MyStack;
import com.pdsa.hospital.datastructure.DoublyLinkedList;
import com.pdsa.hospital.model.Patient;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class QueueService {
    private MyQueue<Patient> regularQueue;
    private MaxHeap emergencyHeap;
    private MyStack<Patient> cancelledAppointments;
    private DoublyLinkedList<Patient> historyList;

    private int totalPatientsServed;
    private int counter;

    public QueueService() {
        this.regularQueue = new MyQueue<>();
        this.emergencyHeap = new MaxHeap(100);
        this.cancelledAppointments = new MyStack<>();
        this.historyList = new DoublyLinkedList<>();
        this.totalPatientsServed = 0;
        this.counter = 1;
    }

    public void addPatientToQueue(Patient patient) {
        patient.setQueueNumber(counter++);
        if (patient.isEmergency()) {
            emergencyHeap.insert(patient);
        } else {
            regularQueue.enqueue(patient);
        }
    }

    public Patient serveNextPatient() {
        Patient nextPatient = null;

        if (!emergencyHeap.isEmpty()) {
            nextPatient = emergencyHeap.extractMax();
        } else if (!regularQueue.isEmpty()) {
            nextPatient = regularQueue.dequeue();
        }

        if (nextPatient != null) {
            historyList.addLast(nextPatient);
            totalPatientsServed++;
            updatePatientStatusInDB(nextPatient.getPatientId(), "Served");
        }

        return nextPatient;
    }

    public void cancelAppointment(Patient patient) {
        cancelledAppointments.push(patient);
        updatePatientStatusInDB(patient.getPatientId(), "Cancelled");
    }

    public Patient undoCancellation() {
        Patient restoredPatient = cancelledAppointments.pop();
        if (restoredPatient != null) {
            if (restoredPatient.isEmergency()) {
                emergencyHeap.insert(restoredPatient);
            } else {
                regularQueue.enqueue(restoredPatient);
            }
            updatePatientStatusInDB(restoredPatient.getPatientId(), "Waiting");
        }
        return restoredPatient;
    }

    // Helper: Modifies row state inside MySQL
    private void updatePatientStatusInDB(int patientId, String status) {
        String query = "UPDATE patients SET status = ? WHERE patient_id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, status);
            stmt.setInt(2, patientId);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public MyQueue<Patient> getRegularQueue() { return regularQueue; }
    public MaxHeap getEmergencyHeap() { return emergencyHeap; }
    public DoublyLinkedList<Patient> getHistoryList() { return historyList; }
    public int getTotalPatientsServed() { return totalPatientsServed; }

}