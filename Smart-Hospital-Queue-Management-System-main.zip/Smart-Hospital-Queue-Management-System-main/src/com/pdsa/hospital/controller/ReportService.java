package com.pdsa.hospital.controller;

import com.pdsa.hospital.datastructure.Node;
import com.pdsa.hospital.model.Patient;

public class ReportService {

    // Generates a simple text-based summary of current stats
    public String generateDailyReport(QueueService queueService) {
        StringBuilder report = new StringBuilder();
        report.append("======= DAILY HOSPITAL REPORT =======\n");
        report.append("Total Patients Served Today: ").append(queueService.getTotalPatientsServed()).append("\n");

        int waitingCount = queueService.getRegularQueue().size() + queueService.getEmergencyHeap().size();
        report.append("Patients Currently Waiting: ").append(waitingCount).append("\n");
        report.append("=====================================\n");

        return report.toString();
    }
}