package com.pdsa.hospital.controller;

import com.pdsa.hospital.database.Database;
import com.pdsa.hospital.datastructure.BinarySearchTree;
import com.pdsa.hospital.model.Patient;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PatientService {
    private BinarySearchTree patientRegistry;

    public PatientService() {
        this.patientRegistry = new BinarySearchTree();
        loadPatientsFromDatabase(); // Automatically pre-populates the BST when the app loads!
    }

    // 1. Saves patient record to MySQL Database and inserts it into the BST index
    public void registerPatientRecord(Patient patient) {
        patientRegistry.insert(patient);

        String query = "INSERT INTO patients (patient_id, patient_name, age, gender, contact_number, doctor_name, emergency, queue_number, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Waiting')";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patient.getPatientId());
            stmt.setString(2, patient.getPatientName());
            stmt.setInt(3, patient.getAge());
            stmt.setString(4, patient.getGender());
            stmt.setString(5, patient.getContactNumber());
            stmt.setString(6, patient.getDoctorName());
            stmt.setBoolean(7, patient.isEmergency());
            stmt.setInt(8, patient.getQueueNumber());

            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 2. Looks up patient immediately via custom BST index
    public Patient findPatientById(int patientId) {
        return patientRegistry.search(patientId);
    }

    // Helper: Loads existing records from database straight into custom BST at startup
    private void loadPatientsFromDatabase() {
        String query = "SELECT * FROM patients";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Patient p = new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("patient_name"),
                        rs.getInt("age"),
                        rs.getString("gender"),
                        rs.getString("contact_number"),
                        rs.getString("doctor_name"),
                        rs.getBoolean("emergency"),
                        rs.getInt("queue_number")
                );
                patientRegistry.insert(p);
            }
        } catch (Exception e) {
            System.out.println("No pre-existing records found to populate the registry index yet.");
        }
    }
}