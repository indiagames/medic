package com.pdsa.hospital.database;

import com.pdsa.hospital.model.Doctor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/hospital_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Lahiru@10"; // CHANGE THIS TO YOUR WORKBENCH PASSWORD

    // Get a fresh connection to the MySQL instance
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Dynamic fetch from the MySQL doctors table to populate our UI components
    public static List<Doctor> getDoctors() {
        List<Doctor> doctorsList = new ArrayList<>();
        String query = "SELECT * FROM doctors";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Doctor doc = new Doctor(
                        rs.getInt("doctor_id"),
                        rs.getString("doctor_name"),
                        rs.getString("specialization"),
                        rs.getString("room_number")
                );
                doctorsList.add(doc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return doctorsList;
    }
}