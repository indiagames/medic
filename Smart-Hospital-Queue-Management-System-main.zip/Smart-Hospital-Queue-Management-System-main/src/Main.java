import com.pdsa.hospital.controller.PatientService;
import com.pdsa.hospital.controller.QueueService;
import com.pdsa.hospital.controller.ReportService;
import com.pdsa.hospital.view.LoginUI;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Run application on Event Dispatch Thread for Swing safe processing
        SwingUtilities.invokeLater(() -> {
            // Instantiate core controllers
            PatientService patientService = new PatientService();
            QueueService queueService = new QueueService();
            ReportService reportService = new ReportService();

            // Fire up login frame!
            new LoginUI(patientService, queueService, reportService).setVisible(true);
        });
    }
}